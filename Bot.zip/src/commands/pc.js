module.exports.run = async (client, message, args) =>{
    message.reply(`I3-9100F GTX 1650 8GB de RAM 120GB SSD HD 1TB`);
};