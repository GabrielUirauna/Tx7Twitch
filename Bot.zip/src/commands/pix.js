module.exports.run = async(client, message, args) => {
    message.reply(`Chave PIX: 43790bb0-e6b8-4235-bf19-e0590c4ee0e1`)
}