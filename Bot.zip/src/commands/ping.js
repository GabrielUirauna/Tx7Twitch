module.exports.run = async(client, message, args) => {
    message.reply(`Ping!`)
}